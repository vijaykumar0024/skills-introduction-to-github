import pygame
import random

class MathPrompt:
    """
    A modal overlay that displays a math question and handles user input.
    """
    def __init__(self, kind="build", level=1):
        """
        Initialize a math prompt.
        
        Args:
            kind (str): The action type ("build", "upgrade", etc.)
            level (int): Difficulty level (1-3)
        """
        self.kind = kind
        self.level = level
        self.active = True
        self.correct = False
        
        # Generate a random math question
        self.question, self.answer = self._generate_question(level)
        
        # User input
        self.user_input = ""
        self.feedback = ""
        self.feedback_color = (255, 255, 255)
        
        # Timer for auto-close after showing result
        self.result_timer = 0
        self.show_result = False
        self.result_duration = 1.5  # seconds
        
    def _generate_question(self, level):
        """
        Generate a math question based on difficulty level.
        
        Returns:
            tuple: (question_string, correct_answer)
        """
        if level == 1:
            # Easy: addition and subtraction up to 50
            a = random.randint(1, 50)
            b = random.randint(1, 50)
            if random.choice([True, False]):
                return f"{a} + {b}", a + b
            else:
                # Ensure positive result
                a, b = max(a, b), min(a, b)
                return f"{a} - {b}", a - b
                
        elif level == 2:
            # Medium: multiplication and division
            if random.choice([True, False]):
                a = random.randint(2, 12)
                b = random.randint(2, 12)
                return f"{a} × {b}", a * b
            else:
                b = random.randint(2, 12)
                answer = random.randint(2, 12)
                a = b * answer
                return f"{a} ÷ {b}", answer
                
        else:
            # Hard: mixed operations
            a = random.randint(5, 20)
            b = random.randint(2, 10)
            c = random.randint(1, 15)
            op = random.choice(['+', '-', '*'])
            
            if op == '+':
                return f"{a} + {b} × {c}", a + (b * c)
            elif op == '-':
                return f"{a} × {b} - {c}", (a * b) - c
            else:
                return f"({a} + {b}) × {c}", (a + b) * c
    
    def handle(self, event):
        """
        Handle pygame events for the math prompt.
        
        Args:
            event: pygame event
        """
        if not self.active or self.show_result:
            return
            
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                # Check answer
                try:
                    user_answer = int(self.user_input)
                    if user_answer == self.answer:
                        self.correct = True
                        self.feedback = "Correct! ✓"
                        self.feedback_color = (0, 255, 0)
                    else:
                        self.correct = False
                        self.feedback = f"Wrong! Correct answer: {self.answer}"
                        self.feedback_color = (255, 0, 0)
                    self.show_result = True
                    self.result_timer = 0
                except ValueError:
                    self.feedback = "Please enter a valid number!"
                    self.feedback_color = (255, 100, 0)
                    
            elif event.key == pygame.K_BACKSPACE:
                self.user_input = self.user_input[:-1]
                self.feedback = ""
                
            elif event.key == pygame.K_ESCAPE:
                # Cancel the prompt
                self.active = False
                self.correct = False
                
            elif event.unicode.isdigit() or (event.unicode == '-' and len(self.user_input) == 0):
                # Allow digits and minus sign at the start
                self.user_input += event.unicode
                self.feedback = ""
    
    def update(self, dt):
        """
        Update the prompt state (for timing).
        
        Args:
            dt (float): Delta time in seconds
        """
        if self.show_result:
            self.result_timer += dt
            if self.result_timer >= self.result_duration:
                self.active = False
    
    def draw(self, screen):
        """
        Draw the math prompt overlay on the screen.
        
        Args:
            screen: pygame surface to draw on
        """
        if not self.active:
            return
            
        # Semi-transparent overlay
        overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        # Get screen dimensions
        width, height = screen.get_size()
        
        # Draw prompt box
        box_width = 500
        box_height = 300
        box_x = (width - box_width) // 2
        box_y = (height - box_height) // 2
        
        # Box background
        pygame.draw.rect(screen, (40, 40, 60), (box_x, box_y, box_width, box_height), border_radius=10)
        pygame.draw.rect(screen, (100, 100, 150), (box_x, box_y, box_width, box_height), width=3, border_radius=10)
        
        # Fonts
        title_font = pygame.font.Font(None, 48)
        question_font = pygame.font.Font(None, 64)
        input_font = pygame.font.Font(None, 56)
        feedback_font = pygame.font.Font(None, 36)
        hint_font = pygame.font.Font(None, 28)
        
        # Title
        title_text = title_font.render("Solve to Build Tower!", True, (255, 255, 255))
        title_rect = title_text.get_rect(center=(width // 2, box_y + 40))
        screen.blit(title_text, title_rect)
        
        # Question
        question_text = question_font.render(self.question + " = ?", True, (255, 255, 100))
        question_rect = question_text.get_rect(center=(width // 2, box_y + 110))
        screen.blit(question_text, question_rect)
        
        # Input box
        input_box_width = 300
        input_box_height = 60
        input_box_x = (width - input_box_width) // 2
        input_box_y = box_y + 160
        
        pygame.draw.rect(screen, (60, 60, 80), (input_box_x, input_box_y, input_box_width, input_box_height), border_radius=5)
        pygame.draw.rect(screen, (150, 150, 200), (input_box_x, input_box_y, input_box_width, input_box_height), width=2, border_radius=5)
        
        # User input text
        if self.user_input:
            input_text = input_font.render(self.user_input, True, (255, 255, 255))
        else:
            input_text = input_font.render("Type answer...", True, (120, 120, 140))
        input_rect = input_text.get_rect(center=(width // 2, input_box_y + 30))
        screen.blit(input_text, input_rect)
        
        # Feedback
        if self.feedback:
            feedback_text = feedback_font.render(self.feedback, True, self.feedback_color)
            feedback_rect = feedback_text.get_rect(center=(width // 2, box_y + 240))
            screen.blit(feedback_text, feedback_rect)
        
        # Hints
        if not self.show_result:
            hint_text = hint_font.render("Press ENTER to submit | ESC to cancel", True, (180, 180, 180))
            hint_rect = hint_text.get_rect(center=(width // 2, box_y + box_height - 20))
            screen.blit(hint_text, hint_rect)